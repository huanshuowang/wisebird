const $ = (id) => document.getElementById(id);


const KEY_URL = {
  gemini: "https://aistudio.google.com/apikey",
  deepseek: "https://platform.deepseek.com/api_keys",
  openai: "https://platform.openai.com/api-keys",
  anthropic: "https://console.anthropic.com/settings/keys",
};

function updateKeyGuide() {
  const p = $("provider").value in KEY_URL ? $("provider").value : "gemini";
  $("keyGuideHint").textContent = t("guide." + p);
  $("keyGuideLink").href = KEY_URL[p];
}



// ---------- rendering (textContent only) ----------

function fillList(id, items) {
  const ul = $(id);
  ul.replaceChildren();
  (items || []).forEach((x) => {
    const li = document.createElement("li");
    li.textContent = x;
    ul.append(li);
  });
  if (!ul.children.length) {
    const li = document.createElement("li");
    li.textContent = "—";
    ul.append(li);
  }
}

const CONF_LABEL = { low: "Low", medium: "Medium", high: "High" };
const capConf = (c) => CONF_LABEL[c] || "Low";

const SVG_NS = "http://www.w3.org/2000/svg";
function svgIcon(d) {
  const svg = document.createElementNS(SVG_NS, "svg");
  svg.setAttribute("viewBox", "0 0 24 24");
  svg.setAttribute("aria-hidden", "true");
  const p = document.createElementNS(SVG_NS, "path");
  p.setAttribute("d", d);
  svg.append(p);
  return svg;
}

function reqRow(name, o) {
  const row = document.createElement("div");
  const meets = o?.meets;
  row.className = "reqrow" + (meets === false ? " no" : meets === true ? "" : " unk");
  const ico = document.createElement("span");
  ico.className = "ico";
  if (meets === true) ico.append(svgIcon("M5 12.5l4.5 4.5L19 7.5"));
  else if (meets === false) ico.append(svgIcon("M6 6l12 12M18 6L6 18"));
  else ico.textContent = "?";
  const b = document.createElement("b");
  b.textContent = name;
  const v = document.createElement("span");
  v.className = "v";
  v.textContent = t("req.line", { v: o?.required || "—" }) + (meets === false && o?.note ? " — " + o.note : "");
  row.append(ico, b, v);
  return row;
}

// 通用的"一排彩色按钮 + 下面一块详情"组件。sponsor 和公司情况各自独立一份（互不影响选中状态）。
// item 形状：{ key, label, tone("good"|"bad"|"mixed"|"unknown"), head, body, evidence }
function toneClass(tone) {
  return tone === "good" ? "sp-green" : tone === "bad" ? "sp-red" : tone === "mixed" ? "sp-amber" : "sp-gray";
}

function makeTabGroup(tabsId, detailId) {
  let active = null;
  let items = [];
  function renderTabs() {
    const tabs = $(tabsId);
    tabs.replaceChildren();
    items.forEach((it) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "sp-pill " + toneClass(it.tone) + (active === it.key ? " active" : "");
      btn.textContent = it.label;
      btn.addEventListener("click", () => {
        active = active === it.key ? null : it.key;
        renderTabs();
      });
      tabs.append(btn);
    });
    renderDetail();
  }
  function renderDetail() {
    const box = $(detailId);
    box.replaceChildren();
    const it = items.find((x) => x.key === active);
    if (!it) {
      const hint = document.createElement("div");
      hint.className = "sp-hint";
      hint.textContent = t("hint.click");
      box.append(hint);
      return;
    }
    const head = document.createElement("div");
    head.className = "sp-head";
    head.textContent = it.head || it.label;
    box.append(head);
    if (it.body) {
      const b = document.createElement("div");
      b.textContent = it.body;
      box.append(b);
    }
    if (it.evidence) {
      const ev = document.createElement("div");
      ev.className = "ev";
      ev.textContent = "“" + it.evidence + "”";
      box.append(ev);
    }
  }
  return {
    set(newItems) {
      items = newItems;
      active = null;
      renderTabs();
    },
  };
}

const sponsorGroup = makeTabGroup("sponsorTabs", "sponsorDetail");
const companyGroup = makeTabGroup("companyTabs", "companyDetail");

const SCAM_TONE = { clean: "good", suspicious: "bad", unclear: "unknown" };
const REVIEW_TONE = { positive: "good", mixed: "mixed", negative: "bad", unknown: "unknown" };

// 列表 / 主卡片里只放很短的"优势 / 减分"小标签，完整分析点开再看
function chipsFor(r, n = 2) {
  const cut = (x) => String(x || "").trim().replace(/[。；;，,.]$/, "").slice(0, UI_LANG === "en" ? 34 : 18);
  const pros = (r.pros && r.pros.length ? r.pros : r.matches || []).map(cut).filter(Boolean).slice(0, n);
  const cons = (r.cons && r.cons.length ? r.cons : [...(r.red_flags || []), ...(r.gaps || [])]).map(cut).filter(Boolean).slice(0, n);
  return { pros, cons };
}

function fillChips(box, r, n) {
  box.replaceChildren();
  const { pros, cons } = chipsFor(r, n);
  const chip = (kind, text) => {
    const c = document.createElement("span");
    c.className = "bchip " + kind;
    c.textContent = (kind === "pro" ? "＋ " : "－ ") + text;
    box.append(c);
  };
  pros.forEach((x) => chip("pro", x));
  cons.forEach((x) => chip("con", x));
  box.hidden = !box.children.length;
}

function addLinks(box, list) {
  box.replaceChildren();
  list.forEach(([label, href]) => {
    const a = document.createElement("a");
    a.textContent = label;
    a.href = href;
    a.target = "_blank";
    a.rel = "noopener";
    box.append(a);
  });
}

const expText = (r) => {
  const v = String(r?.requirements?.experience?.required || "").trim();
  return t("exp.line", { v: v && !/^(未提及|not mentioned|n\/a|none|-|—)$/i.test(v) ? v : t("exp.none") });
};
let lastResult = null;

function render(r) {
  r = enforceGates(r); // 以前存下的旧结果也按同样的规则显示
  lastResult = r;
  const key = verdictKey(r.verdict);
  const score = Number(r.score);
  $("heroCard").className = "hero tone-" + key;
  $("jobline").textContent = [r.job?.title, r.job?.company].filter(Boolean).join(" · ");
  $("scoreNum").textContent = Number.isFinite(score) ? score : "–";
  const arc = $("gaugeArc");
  arc.style.transition = "none";
  arc.style.strokeDashoffset = "213.6";
  void arc.getBoundingClientRect();
  arc.style.transition = "";
  requestAnimationFrame(() => (arc.style.strokeDashoffset = String(213.6 * (1 - Math.max(0, Math.min(10, score || 0)) / 10))));
  $("verdict").textContent = t("verdict." + key);
  fillChips($("mainChips"), r, 3);

  const flags = (r.red_flags || []).filter(Boolean);
  $("flagsBox").hidden = !flags.length;
  fillList("flags", flags);

  const salEl = $("salary");
  if (hasSalary(r.salary)) {
    salEl.textContent = r.salary;
    salEl.className = "salary" + (belowMin(r.salary) ? " low" : "");
  } else {
    salEl.textContent = t("sal.none");
    salEl.className = "salary none";
  }

  const ex = $("expPill");
  ex.textContent = expText(r);
  ex.className = "salary exp" + (r.requirements?.experience?.meets === false ? " low" : "");

  const req = r.requirements || {};
  $("reqBox").replaceChildren(reqRow(t("req.edu"), req.education), reqRow(t("req.exp"), req.experience), ...(req.timing ? [reqRow(t("req.timing"), req.timing)] : []));
  $("summary").textContent = r.summary || "";

  const s = r.sponsor || {};
  const tone = (st) => (st === "good" ? "good" : st === "bad" ? "bad" : "unknown");
  // 只有 JD 里真的提到了（好或坏）才单独给一个彩色按钮；一个都没提到时，合并成一个灰色"未提及"按钮。
  const sponsorItems = [];
  [["opt", "OPT"], ["stem_opt", "STEM OPT"], ["h1b", "H-1B"]].forEach(([k, label]) => {
    const x = s[k];
    if (x?.status === "good" || x?.status === "bad") {
      sponsorItems.push({ key: k, label, tone: tone(x.status), head: `${label} · ${t("st." + x.status)}`, body: x.detail, evidence: x.evidence });
    }
  });
  if (s.restriction?.status === "bad") {
    sponsorItems.push({ key: "restriction", label: t("spon.restr"), tone: "bad", head: t("spon.restr.head"), body: s.restriction.detail, evidence: s.restriction.evidence });
  }
  if (!sponsorItems.length) {
    sponsorItems.push({ key: "none", label: t("spon.none"), tone: "unknown", head: t("spon.none.head"), body: t("spon.none.body") });
  }
  sponsorGroup.set(sponsorItems);

  const chRow = $("companyHistoryRow");
  chRow.replaceChildren();
  const chRaw = (s.company_history?.detail || "").trim();
  const chText = !chRaw || /no reliable knowledge/i.test(chRaw) ? t("hist.none") : chRaw;
  const chTag = document.createElement("div");
  chTag.className = "tag";
  chTag.textContent = t("hist.tag");
  const chBody = document.createElement("div");
  chBody.textContent = chText + t("conf.tail", { c: capConf(s.company_history?.confidence) });
  chRow.append(chTag, chBody);

  const co = encodeURIComponent(r.job?.company || "");
  addLinks($("links"), co ? [
    [t("link.h1b"), `https://www.myvisajobs.com/Search_Visa_Sponsor.aspx?N=0&v=${co}`],
    ["H1BData", `https://h1bdata.info/index.php?em=${co}&job=&city=&year=all+years`],
  ] : []);

  const company = r.company || {};
  const scam = company.scam_check || {};
  const scamSt = scam.status || "unclear";
  const hc = company.headcount || {};
  const ri = company.review_impression || {};
  const riSt = ri.status || "unknown";
  companyGroup.set([
    { key: "scam", label: t("scam." + scamSt), tone: SCAM_TONE[scamSt] || "unknown", head: `${t("co.legit")} · ${t("scam." + scamSt)}`, body: (scam.reasons || []).join("; "), evidence: scam.evidence },
    { key: "headcount", label: hc.estimate || t("co.unknown"), tone: "unknown", head: t("co.size"), body: t("co.size.body", { c: capConf(hc.confidence) }) },
    { key: "review", label: t("rev." + riSt), tone: REVIEW_TONE[riSt] || "unknown", head: `${t("co.reviews")} · ${t("rev." + riSt)}`, body: (ri.note ? ri.note.replace(/[。.]?$/, UI_LANG === "en" ? ". " : "。") : "") + t("co.ref") },
  ]);

  addLinks($("companyLinks"), co ? [
    [t("link.li"), `https://www.linkedin.com/search/results/companies/?keywords=${co}`],
    [t("link.gd"), `https://www.google.com/search?q=site:glassdoor.com+${co}+reviews`],
    [t("link.ind"), `https://www.google.com/search?q=site:indeed.com+${co}+reviews`],
    [t("link.scam"), `https://www.google.com/search?q=${co}+scam+OR+fraud+reviews`],
  ] : []);

  fillList("matches", r.matches);
  fillList("gaps", r.gaps);
  fillList("points", r.jd_points);
}

function showCached(c) {
  render(c.r);
  $("preview").hidden = true;
  $("result").hidden = false;
  setStatus("");
  $("cachedText").textContent = t(c.stale ? "res.stale" : "res.cached", { when: ago(c.ts) });
  $("cachedNote").hidden = false;
}
// 顶层页面读不到时：看看是不是有跨站的大 iframe 还没授权
async function blockedFrameOrigins(tab) {
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => [...document.querySelectorAll("iframe")]
        .filter((f) => f.offsetWidth > 300 && f.offsetHeight > 300)
        .map((f) => { try { return new URL(f.src, location.href).origin; } catch { return ""; } })
        .filter((o) => o && o !== location.origin),
    });
    const out = [];
    for (const o of [...new Set(result || [])]) {
      if (!(await chrome.permissions.contains({ origins: [o + "/*"] }))) out.push(o);
    }
    return out;
  } catch { return []; }
}

// ---------- main flow ----------
function setStatus(msg, err) {
  const s = $("status");
  s.textContent = msg;
  s.className = "status" + (err ? " err" : "");
  s.hidden = !msg;
}

// 岗位正文在没授权过的别的网站的 iframe 里：给一个按钮，用户点了才请求读取那个站点
function showGrant(origin, tab) {
  const box = $("status");
  box.className = "status";
  box.hidden = false;
  box.replaceChildren();
  const p = document.createElement("p");
  p.textContent = t("rd.iframe", { o: new URL(origin).hostname });
  p.style.margin = "0 0 12px";
  const btn = document.createElement("button");
  btn.className = "primary";
  btn.textContent = t("rd.iframe.btn", { o: new URL(origin).hostname });
  btn.addEventListener("click", async () => {
    const ok = await chrome.permissions.request({ origins: [origin + "/*"] });
    if (ok) readJob();
  });
  box.append(p, btn);
}

let currentJob = null;

async function readJob() {
  $("cachedNote").hidden = true;
  $("result").hidden = true;
  $("preview").hidden = true;
  cfg = await store.get();
  if (!cfg.apiKey || !cfg.resume) {
    showSettings(true);
    setStatus("");
    return;
  }
  cfg.provider = cfg.provider || "gemini";
  setStatus(t("rd.reading"));
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const job = await readTabJobPatient(tab);
    if (!job || job.text.length < 200) {
      const blocked = await blockedFrameOrigins(tab);
      if (blocked.length) {
        showGrant(blocked[0], tab);
        return;
      }
      throw new Error(t("rd.fail"));
    }
    currentJob = job;
    const hitc = await cachedFor(job); // 这个岗位分析过：直接显示，不用再点、也不再调用 AI
    if (hitc) { showCached(hitc); return; }
    $("pvTitle").textContent = [job.title, job.company].filter(Boolean).join(" · ") || job.pageTitle;
    const method = ["jsonld", "heading", "scored", "selector", "body"].includes(job.method) ? t("m." + job.method) : job.method;
    $("pvMeta").textContent = t("rd.chars", { n: job.text.length, m: method }) + (job.method === "body" || job.thin || job.noBody || job.text.length < 600 ? t("rd.warn") : "");
    $("pvSnippet").textContent = job.text.replace(/\s+/g, " ").slice(0, 240) + "…";
    $("preview").hidden = false;
    setStatus("");
  } catch (e) {
    setStatus(t("err.prefix") + (e.message || e), true);
  }
}


async function analyze(force) {
  const job = currentJob;
  if (!job) return;
  if (force !== true) {
    const hitc = await cachedFor(job);
    if (hitc) { showCached(hitc); return; }
  }
  $("cachedNote").hidden = true;
  $("preview").hidden = true;
  setStatus(t("an.busy"));
  try {
    const r = await runAnalysis(job);
    render(r);
    if (!job.thin) {
      await saveToHistory(r, job);
      await cachePut(job.url, job, r);
    }
    setStatus("");
    $("result").hidden = false;
  } catch (e) {
    $("preview").hidden = false;
    setStatus(t("err.prefix") + (e.message || e), true);
  }
}

const VIEWS = ["settings", "main", "batch", "history", "starred"];
function showView(name) {
  VIEWS.forEach((id) => ($(id).hidden = id !== name));
  $("batchBtn").classList.toggle("active", name === "batch");
  $("historyBtn").classList.toggle("active", name === "history");
  $("starBtn").classList.toggle("active", name === "starred");
  $("gear").classList.toggle("active", name === "settings");
  if (name === "history") renderHistory();
  if (name === "starred") renderStarred();
  if (name === "batch") restoreBatch();
}
function showSettings(show) {
  showView(show ? "settings" : "main");
}

// ---------- 初筛：只读当前这一屏已加载的搜索结果，不点击不翻页；整页只发 1 次请求 ----------
function searchStatus(msg, err) {
  const el = $("searchStatus");
  el.textContent = msg;
  el.hidden = !msg;
  el.className = "status" + (err ? " err" : "");
}

const SALARY_RE = /\$\s?\d[\d,.]*\s?[kK]?(?:\s*[-–—to]+\s*\$?\s?\d[\d,.]*\s?[kK]?)?(?:\s*\/\s*(?:yr|hr|year|hour|mo|month))?/;

async function scanSearchResults() {
  $("searchList").replaceChildren();
  $("searchSummary").hidden = true;
  $("openChecked").hidden = true;
  cfg = await store.get();
  if (!cfg.apiKey || !cfg.resume) {
    showView("settings");
    return;
  }
  cfg.provider = cfg.provider || "gemini";
  searchStatus(t("qs.reading"));
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const [{ result: page }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: extractSearchResults });
    const d = page?.debug;
    $("searchDebug").textContent = d
      ? t("qs.diag", { host: d.host, a: d.componentKeyEls, b: d.occludableEls, c: d.jobLinks }) + (d.sampleHrefs.length ? t("qs.samples", { s: d.sampleHrefs.join(" ; ") }) : "")
      : "";
    if (!page || !page.results.length) throw new Error(t("qs.none"));
    searchStatus(t("qs.found", { n: page.results.length }));
    const needVisa = wantsVisa(cfg);
    const system = buildQuickScanSystem({ criteria: cfg.scanCriteria, profile: cfg.profile, lang: UI_LANG, needVisa, minSalary: Number(cfg.minSalary) > 0 ? Number(cfg.minSalary) : 0 });
    const user = `RESUME:\n${cfg.resume}\n\nJOB CARDS (${page.results.length} total):\n` +
      page.results.map((r, i) => `[${i}] url: ${r.url}\n${r.cardText}`).join("\n---\n");
    const raw = await callLLM(system, user);
    const data = parseJSON(raw);
    const rows = data.results || [];
    const byUrl = new Map(rows.map((x) => [x.url, x]));
    searchStatus("");
    const items = page.results.map((r, i) => ({ ...r, verdict: byUrl.get(r.url) || rows[i] }));
    renderSearchResults(items);
    await chrome.storage.local.set({ lastScreen: { ts: Date.now(), items } });
  } catch (e) {
    searchStatus(t("err.prefix") + (e.message || e), true);
  }
}

let searchHasItems = false;
function setSearchOpen(open) {
  $("searchSummary").setAttribute("aria-expanded", String(open));
  $("searchList").hidden = !open;
  $("openChecked").hidden = !open || !searchHasItems;
}
$("searchSummary").addEventListener("click", () => setSearchOpen($("searchSummary").getAttribute("aria-expanded") !== "true"));

function renderSearchResults(items, { collapsed = false } = {}) {
  const list = $("searchList");
  list.replaceChildren();
  const tally = { open: 0, no: 0, unclear: 0, sal: 0, low: 0 };
  items.forEach((it) => {
    const v = it.verdict || {};
    const qv = v.quick_verdict === "打开看看" ? "open" : v.quick_verdict === "大概率不行" ? "no" : "unclear";
    const salary = (v.salary || (it.cardText || "").match(SALARY_RE)?.[0] || "").trim();
    const hasSal = hasSalary(salary);
    const low = hasSal && belowMin(salary);
    tally[qv]++;
    if (hasSal) tally.sal++;
    if (low) tally.low++;

    const row = document.createElement("label");
    row.className = "searchRow";

    const cb = document.createElement("input");
    cb.type = "checkbox";
    cb.checked = qv !== "no" && !low;
    cb.dataset.url = it.url;

    const main = document.createElement("div");
    main.className = "searchMain";
    const title = document.createElement("div");
    title.className = "searchTitle";
    title.textContent = v.title || (it.cardText || "").split("\n")[0] || it.url;
    main.append(title);
    const co = [v.company, v.location].filter(Boolean).join(" · ");
    if (co) {
      const c = document.createElement("div");
      c.className = "searchCo";
      c.textContent = co;
      main.append(c);
    }
    const meta = document.createElement("div");
    meta.className = "searchMeta";
    const chip = (cls, text) => {
      const c = document.createElement("span");
      c.className = "chip " + cls;
      c.textContent = text;
      meta.append(c);
    };
    chip("v-" + qv, t("qs.v." + qv));
    if (hasSal) chip(low ? "sal-low" : Number(cfg.minSalary) > 0 ? "sal-ok" : "", low ? `${salary} · ${t("qs.sal.below")}` : salary);
    else chip("", t("qs.sal.none"));
    main.append(meta);
    if (v.reason) {
      const why = document.createElement("div");
      why.className = "searchWhy";
      why.textContent = v.reason;
      main.append(why);
    }
    row.append(cb, main);
    list.append(row);
  });
  const sum = $("searchSummary");
  sum.textContent = t("qs.summary", { n: items.length, o: tally.open, x: tally.no + tally.low, u: tally.unclear, s: tally.sal });
  sum.hidden = !items.length;
  searchHasItems = items.length > 0;
  $("searchClear").hidden = !searchHasItems;
  setSearchOpen(!collapsed);
}

$("openChecked")?.addEventListener("click", () => {
  const urls = Array.from($("searchList").querySelectorAll('input[type="checkbox"]:checked')).map((cb) => cb.dataset.url);
  urls.forEach((url) => chrome.tabs.create({ url, active: false }));
});

async function restoreBatch() {
  const { batchJob, lastScreen } = await chrome.storage.local.get(["batchJob", "lastScreen"]);
  if (lastScreen?.items?.length && !$("searchList").children.length) {
    renderSearchResults(lastScreen.items, { collapsed: true });
    searchStatus(t("batch.restored", { when: ago(lastScreen.ts) }));
  }
  renderBatchJob(batchJob);
}

// ---------- batch: read tabs the user already opened themselves ----------
const BATCH_URL_PATTERNS = ["*://www.linkedin.com/*", "*://*.joinhandshake.com/*"];

function batchStatus(msg, err) {
  const el = $("batchStatus");
  el.textContent = msg;
  el.hidden = !msg;
  el.className = "status" + (err ? " err" : "");
}

// 批量分析在后台（background.js）里跑：这里只负责找出要分析的标签页、下达任务，再把后台写进存储的进度画出来
const jobIsLive = (job) => job && job.status === "running" && Date.now() - job.heartbeat < 120000;

async function showBatchDebug(job) {
  const { bgLog } = await chrome.storage.local.get("bgLog");
  const age = job ? Math.round((Date.now() - job.heartbeat) / 1000) : null;
  const wrong = !!bgNote || !!job?.error || (job && job.status === "interrupted") || (job && job.status === "running" && !jobIsLive(job));
  // 一切正常时不显示任何技术信息；出问题时才把原因写出来
  $("batchDebug").textContent = wrong
    ? (bgNote ? bgNote + "\n" : "") + (job ? t("bt.diag", { s: t("bt.st." + job.status), a: job.done, b: job.total, h: age, m: (job.error ? job.error + " | " : "") + (bgLog?.m || "—") }) : "")
    : "";
}

let batchOpen = null; // null = 还没决定：从"上次结果"恢复时默认收起，正在跑或刚跑完时展开
function setBatchOpen(open) {
  batchOpen = open;
  $("batchSummary").setAttribute("aria-expanded", String(open));
  $("batchList").hidden = !open;
}
$("batchSummary").addEventListener("click", () => setBatchOpen(batchOpen === false));

function renderBatchJob(job) {
  const list = $("batchList");
  const y = document.documentElement.scrollTop;
  list.replaceChildren();
  $("batchStop").hidden = !jobIsLive(job);
  $("batchClear").hidden = !job || jobIsLive(job);
  if (!job) {
    batchStatus("");
    $("batchSummary").hidden = true;
    return;
  }
  if (jobIsLive(job)) batchOpen = true;
  else if (batchOpen === null) batchOpen = false;
  const cnt = { go: 0, try: 0, no: 0, err: 0 };
  job.rows.forEach((rw) => {
    if (rw.status === "done") cnt[verdictKey(enforceGates(rw.r).verdict)]++;
    else if (rw.status === "error") cnt.err++;
  });
  const sum = $("batchSummary");
  sum.textContent = t("bt.sum", { n: job.rows.length, g: cnt.go, y: cnt.try, x: cnt.no, e: cnt.err ? ` · ⚠ ${cnt.err}` : "" });
  sum.hidden = false;
  setBatchOpen(batchOpen);
  job.rows.forEach((rw) => {
    const rowEl = document.createElement("div");
    rowEl.className = "batchRow";
    if (rw.status === "done") renderBatchRow(rowEl, rw.r, rw.job, rw.tabId, rw.cached);
    else if (rw.status === "error") {
      rowEl.textContent = `⚠ ${rw.title}: ${rw.error}`;
      rowEl.classList.add("batchError");
    } else {
      rowEl.textContent = (rw.status === "running" ? "⏳ " : "· ") + rw.title;
      rowEl.classList.add("batchWait");
    }
    list.append(rowEl);
  });
  const live = jobIsLive(job);
  const state = live ? "running" : job.status === "running" ? "interrupted" : job.status;
  batchStatus(
    state === "running" ? t("bt.progress", { a: job.done, b: job.total }) + " · " + t("bt.bg")
      : state === "done" ? (Date.now() - (job.finishedAt || job.startedAt) < 90000 ? t("bt.justdone", { n: job.total }) : t("bt.last", { when: ago(job.finishedAt || job.startedAt), n: job.total }))
      : state === "cancelled" ? t("bt.cancelled")
      : t("bt.interrupted"),
    state === "interrupted"
  );
  document.documentElement.scrollTop = y;
  showBatchDebug(job);
  if (!live) chrome.action.setBadgeText({ text: "" }); // 看到结果了，清掉图标上的徽标
}

async function scanAndAnalyzeTabs() {
  cfg = await store.get();
  if (!cfg.apiKey || !cfg.resume) {
    showView("settings");
    return;
  }
  const { batchJob } = await chrome.storage.local.get("batchJob");
  if (jobIsLive(batchJob)) {
    batchStatus(t("bt.already"));
    return;
  }
  batchStatus(t("bt.finding"));
  let tabs = [];
  try {
    // 只看"当前这个窗口"里的岗位标签页，不碰别的窗口；当前正停着的这页（搜索结果页）也不算
    tabs = await chrome.tabs.query({ url: BATCH_URL_PATTERNS, currentWindow: true });
    const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
    tabs = tabs.filter((tb) => !active || tb.id !== active.id).sort((x, y) => x.index - y.index);
    const seenKeys = new Set(); // 同一个岗位被开了两次，也只算一个
    tabs = tabs.filter((tb) => !seenKeys.has(jobKey(tb.url)) && seenKeys.add(jobKey(tb.url)));
  } catch (e) {
    batchStatus(t("bt.listfail") + (e.message || e), true);
    return;
  }
  if (!tabs.length) {
    batchStatus(t("bt.none"), true);
    return;
  }
  const cache = await cacheGetAll();
  const sig = cfgSig();
  const cachedN = tabs.filter((tb) => cache[jobKey(tb.url)]?.sig === sig).length;
  batchStatus(t("bt.found", { n: tabs.length, f: tabs.length - cachedN, c: cachedN }));
  const list = tabs.map(({ id, url, title }) => ({ id, url, title }));
  const t0 = Date.now();
  batchStatus(t("bt.sent", { n: list.length }));
  // 先请后台去跑：要同时满足"后台回执了"和"几秒内真的写出了任务进度"，否则就改在弹窗里跑（功能照常，
  // 只是关掉弹窗会中断），并把原因写在界面上——不能让人对着一片空白干等
  let why = "";
  try {
    const res = await Promise.race([
      chrome.runtime.sendMessage({ type: "batch:start", tabs: list }),
      new Promise((_, rej) => setTimeout(() => rej(new Error("no reply in 3s")), 3000)),
    ]);
    if (!res?.ok) why = "no ack";
  } catch (e) {
    why = String(e.message || e);
  }
  if (!why) {
    let started = false;
    for (let i = 0; i < 12 && !started; i++) { // 最多等 6 秒
      const { batchJob } = await chrome.storage.local.get("batchJob");
      started = !!batchJob && batchJob.startedAt >= t0;
      if (!started) await new Promise((r) => setTimeout(r, 500));
    }
    if (!started) why = "background did not start the job";
  }
  if (why) {
    bgNote = t("bt.nobg", { e: why });
    batchStatus(bgNote, true);
    popupCancel = false;
    runBatch(list, { isCancelled: () => popupCancel, badge: () => {} }).catch((e) => batchStatus(String(e.message || e), true));
  }
}
let popupCancel = false;
let bgNote = ""; // 后台没响应时的说明：进度状态会覆盖状态行，所以另外固定显示在诊断行里

function renderBatchRow(rowEl, r, job, tabId, cached) {
  r = enforceGates(r);
  rowEl.textContent = "";
  rowEl.className = "batchRow";
  const key = verdictKey(r.verdict);
  const main = document.createElement("div");
  main.className = "batchMain";
  const title = document.createElement("div");
  title.className = "batchTitle";
  title.textContent = [r.job?.company || job.company, r.job?.title || job.title].filter(Boolean).join(" · ") || job.pageTitle;
  const meta = document.createElement("div");
  meta.className = "ev";
  meta.textContent = (hasSalary(r.salary) ? r.salary : t("sal.none")) + " · " + expText(r) + (cached ? " · " + t("bt.cached") : "");
  main.append(title, meta);
  if (job?.chars) { // 读了多少字，一眼能看出有没有读全
    const rd = document.createElement("div");
    rd.className = "exline" + (job.thin || job.chars < 1200 ? " warn" : "");
    rd.textContent = job.thin || job.chars < 1200 ? t("bt.thin", { n: job.chars }) : t("bt.read", { n: job.chars });
    main.append(rd);
  }
  const box = document.createElement("div");
  box.className = "bchips";
  fillChips(box, r, 2);
  if (!box.hidden) main.append(box);

  const score = document.createElement("div");
  score.className = "batchScore " + key;
  const num = document.createElement("div");
  num.textContent = r.score;
  const vd = document.createElement("small");
  vd.textContent = t("verdict." + key);
  score.append(num, vd);

  const openBtn = document.createElement("button");
  openBtn.className = "ghost";
  openBtn.textContent = "↗";
  openBtn.title = t("bt.jump");
  openBtn.addEventListener("click", async (e) => {
    e.stopPropagation();
    let ok = false;
    if (tabId) {
      try { await chrome.tabs.get(tabId); await chrome.tabs.update(tabId, { active: true }); ok = true; } catch {} // 标签页已关：改为重新打开
    }
    if (!ok) chrome.tabs.create({ url: job.url, active: false });
  });

  rowEl.append(main, score, openBtn);
  rowEl.title = (r.summary ? r.summary + "\n\n" : "") + t("bt.rowtip");
  rowEl.addEventListener("click", () => showJobDetail(r, job));
}

// 点批量列表 / 收藏里的某一条，切到和单个分析一样的详细面板
function showJobDetail(r, job) {
  $("cachedNote").hidden = true;
  currentJob = job;
  render(r);
  showView("main");
  $("preview").hidden = true;
  $("result").hidden = false;
  setStatus("");
}

// ---------- saved ----------
let historyTier = "go";

// ---- 自定义确认弹窗（扩展弹窗里原生 confirm() 不可靠，这里自己画一个）----
function confirmDialog(message) {
  return new Promise((resolve) => {
    $("modalMsg").textContent = message;
    $("modal").hidden = false;
    const done = (v) => {
      $("modal").hidden = true;
      $("modalOk").onclick = $("modalCancel").onclick = $("modal").onclick = null;
      document.removeEventListener("keydown", onKey);
      resolve(v);
    };
    const onKey = (e) => { if (e.key === "Escape") done(false); };
    document.addEventListener("keydown", onKey);
    $("modalOk").onclick = () => done(true);
    $("modalCancel").onclick = () => done(false);
    $("modal").onclick = (e) => { if (e.target === $("modal")) done(false); };
    $("modalCancel").focus(); // 默认焦点放在"取消"上，避免手滑回车就清空
  });
}

// ---- 收藏夹：用户自己用 ☆ 收藏的岗位，单独存一份，所以"清空存档"不会动它 ----
async function favGetAll() {
  return (await chrome.storage.local.get("favorites")).favorites || [];
}

function makeJobRow(h, { favKeys, inStarred, rerender }) {
  const row = document.createElement("div");
  row.className = "histRow";

  const main = document.createElement("div");
  main.className = "histMain";
  const ti = document.createElement("div");
  ti.className = "histTitle";
  ti.textContent = [h.company, h.title].filter(Boolean).join(" · ") || t("fav.unnamed");
  const meta = document.createElement("div");
  meta.className = "ev";
  meta.textContent = `${new Date(h.ts).toLocaleDateString()} · ${hasSalary(h.salary) ? h.salary : t("sal.none")}` + (h.result ? " · " + expText(h.result) : "");
  main.append(ti, meta);

  const score = document.createElement("div");
  score.className = "histScore";
  score.textContent = h.score;

  const key = jobKey(h.url);
  const star = document.createElement("button");
  star.className = "ghost star";
  const paintStar = (on) => {
    star.classList.toggle("on", on);
    star.textContent = on ? "★" : "☆";
    star.title = on ? t("star.remove") : t("star.add");
  };
  paintStar(favKeys.has(key));
  star.addEventListener("click", async (e) => {
    e.stopPropagation();
    const favs = await favGetAll();
    const i = favs.findIndex((f) => f.key === key);
    if (i >= 0) favs.splice(i, 1);
    else favs.unshift({ key, ts: Date.now(), rec: h });
    await chrome.storage.local.set({ favorites: favs });
    paintStar(i < 0);
    if (inStarred) rerender();
  });

  const openBtn = document.createElement("button");
  openBtn.className = "ghost";
  openBtn.textContent = "↗";
  openBtn.title = t("fav.open.tip");
  openBtn.addEventListener("click", async (e) => {
    e.stopPropagation();
    chrome.tabs.create({ url: h.url, active: false });
    if (inStarred) return;
    row.classList.add("opened");
    openBtn.classList.add("done");
    openBtn.textContent = "✓";
    const { history: cur = [] } = await chrome.storage.local.get("history");
    const rec = cur.find((x) => x.id === h.id);
    if (rec) {
      rec.openedAt = Date.now();
      await chrome.storage.local.set({ history: cur });
    }
  });
  if (h.openedAt && !inStarred) { // 之前点开过：淡一点 + 打勾，连续点很多个时不会重复点
    row.classList.add("opened");
    openBtn.classList.add("done");
    openBtn.textContent = "✓";
  }

  row.append(main, score, star, openBtn);

  if (!inStarred) { // 存档里可以单条删除；收藏夹里取消 ★ 就是移除
    const delBtn = document.createElement("button");
    delBtn.className = "ghost";
    delBtn.textContent = "×";
    delBtn.title = t("fav.del.tip");
    delBtn.addEventListener("click", async (e) => {
      e.stopPropagation();
      const { history: cur = [] } = await chrome.storage.local.get("history");
      await chrome.storage.local.set({ history: cur.filter((x) => x.id !== h.id) });
      rerender();
    });
    row.append(delBtn);
  }

  if (h.result) {
    row.classList.add("clickable");
    row.title = t("bt.rowtip");
    row.addEventListener("click", () => showJobDetail(h.result, h.job || { url: h.url, title: h.title, company: h.company, pageTitle: h.title }));
  } else {
    row.title = t("fav.old.tip");
  }
  return row;
}

async function renderHistory() {
  let { history = [] } = await chrome.storage.local.get("history");
  // 之前存进来、但按"硬性条件不符 = 不建议"现在不该留的，顺手清掉
  const kept = history.filter((h) => !h.result || enforceGates(h.result).verdict !== "不建议");
  if (kept.length !== history.length) {
    history = kept;
    await chrome.storage.local.set({ history });
  }
  const favKeys = new Set((await favGetAll()).map((f) => f.key));
  const list = $("historyList");
  list.replaceChildren();
  const items = history.filter((h) => h.tier === historyTier).sort((a, b) => b.ts - a.ts);
  if (!items.length) {
    const p = document.createElement("div");
    p.className = "status";
    p.textContent = t("fav.empty");
    list.append(p);
    return;
  }
  items.forEach((h) => list.append(makeJobRow(h, { favKeys, inStarred: false, rerender: renderHistory })));
}

async function renderStarred() {
  const favs = await favGetAll();
  const list = $("starredList");
  list.replaceChildren();
  $("starClear").hidden = !favs.length;
  if (!favs.length) {
    const p = document.createElement("div");
    p.className = "status";
    p.textContent = t("starred.empty");
    list.append(p);
    return;
  }
  const favKeys = new Set(favs.map((f) => f.key));
  favs.forEach((f) => list.append(makeJobRow(f.rec, { favKeys, inStarred: true, rerender: renderStarred })));
}

// ---------- settings ----------
function applyVisaMode(on) {
  document.body.classList.toggle("novisa", !on);
}

async function loadSettings() {
  const c = await store.get();
  UI_LANG = c.uiLang === "en" || c.uiLang === "zh" ? c.uiLang : detectLang();
  applyI18n();
  $("uiLangSel").value = UI_LANG;
  $("provider").value = c.provider || "gemini";
  $("apiKey").value = c.apiKey || "";
  $("model").value = c.model || "";
  $("model").placeholder = PROVIDERS[$("provider").value].model;
  $("profile").value = c.profile || "";
  $("needVisa").checked = wantsVisa(c);
  applyVisaMode(wantsVisa(c));
  $("availability").value = c.availability || "";
  $("expTolerance").value = c.expTolerance ?? DEFAULT_EXP_TOLERANCE;
  $("minSalary").value = Number(c.minSalary) > 0 ? c.minSalary : "";
  $("scanCriteria").value = c.scanCriteria || "";
  $("resume").value = c.resume || "";
  updateKeyGuide();
}

$("uiLangSel").addEventListener("change", async () => {
  UI_LANG = $("uiLangSel").value === "en" ? "en" : "zh";
  await store.set({ uiLang: UI_LANG });
  applyI18n();
  updateKeyGuide();
  if (lastResult && !$("result").hidden) render(lastResult);
});
$("needVisa").addEventListener("change", () => applyVisaMode($("needVisa").checked));
$("provider").addEventListener("change", () => {
  $("model").value = "";
  $("model").placeholder = PROVIDERS[$("provider").value].model;
  updateKeyGuide();
});
$("gear").addEventListener("click", () => showSettings($("settings").hidden));
$("batchBtn").addEventListener("click", () => showView($("batch").hidden ? "batch" : "main"));
$("historyBtn").addEventListener("click", () => showView($("history").hidden ? "history" : "main"));
$("starBtn").addEventListener("click", () => showView($("starred").hidden ? "starred" : "main"));
$("scanTabs").addEventListener("click", scanAndAnalyzeTabs);
$("batchClear").addEventListener("click", async () => {
  if (!(await confirmDialog(t("cf.last")))) return;
  batchOpen = null;
  await chrome.storage.local.remove("batchJob");
  renderBatchJob(null);
  batchStatus("");
});
$("searchClear").addEventListener("click", async () => {
  if (!(await confirmDialog(t("cf.last")))) return;
  await chrome.storage.local.remove("lastScreen");
  $("searchList").replaceChildren();
  $("searchSummary").hidden = true;
  $("searchClear").hidden = true;
  $("openChecked").hidden = true;
  searchHasItems = false;
  searchStatus("");
});
$("batchStop").addEventListener("click", () => { popupCancel = true; chrome.runtime.sendMessage({ type: "batch:cancel" }).catch(() => {}); });
chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch.batchJob) renderBatchJob(ch.batchJob.newValue); });
$("scanSearch").addEventListener("click", scanSearchResults);
function setHistoryTier(tier) {
  historyTier = tier;
  $("histTabGo").classList.toggle("active", tier === "go");
  $("histTabTry").classList.toggle("active", tier === "try");
  renderHistory();
}
$("histTabGo").addEventListener("click", () => setHistoryTier("go"));
$("histTabTry").addEventListener("click", () => setHistoryTier("try"));
$("histClear").addEventListener("click", async () => {
  const { history: cur = [] } = await chrome.storage.local.get("history");
  const n = cur.filter((x) => x.tier === historyTier).length;
  if (!n) return;
  // 必须先确认；收藏夹是单独存的，不受影响
  const ok = await confirmDialog(t("cf.archive", { tier: t(historyTier === "go" ? "fav.go" : "fav.try"), n }));
  if (!ok) return;
  await chrome.storage.local.set({ history: cur.filter((x) => x.tier !== historyTier) });
  renderHistory();
});
$("starClear").addEventListener("click", async () => {
  const favs = await favGetAll();
  if (!favs.length) return;
  if (!(await confirmDialog(t("cf.fav", { n: favs.length })))) return;
  await chrome.storage.local.set({ favorites: [] });
  renderStarred();
});
$("rerun").addEventListener("click", () => {
  showSettings(false);
  readJob();
});
$("go").addEventListener("click", () => analyze());
$("reanalyze").addEventListener("click", () => { $("result").hidden = true; analyze(true); });
async function persistSettings() {
  const min = parseFloat($("minSalary").value);
  const tol = parseFloat($("expTolerance").value);
  await store.set({
    uiLang: UI_LANG,
    provider: $("provider").value,
    apiKey: $("apiKey").value.trim(),
    model: $("model").value.trim(),
    profile: $("profile").value.trim(),
    needVisa: $("needVisa").checked,
    availability: $("availability").value.trim(),
    expTolerance: Number.isFinite(tol) ? tol : DEFAULT_EXP_TOLERANCE,
    minSalary: Number.isFinite(min) && min > 0 ? min : null,
    scanCriteria: $("scanCriteria").value.trim(),
    resume: $("resume").value.trim(),
  });
  applyVisaMode($("needVisa").checked);
}
// 设置里改任何一项都立刻保存（输入停顿 0.4 秒后；下拉 / 开关马上存），不用再点按钮
let saveTimer = null;
function autosaveSettings(immediate) {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(async () => {
    await persistSettings();
    const tick = $("savedTick");
    tick.textContent = t("set.saved");
    tick.classList.add("on");
    clearTimeout(tick._t);
    tick._t = setTimeout(() => tick.classList.remove("on"), 1400);
  }, immediate ? 0 : 400);
}
$("settings").querySelectorAll("input, textarea, select").forEach((el) => {
  el.addEventListener("input", () => autosaveSettings(false));
  el.addEventListener("change", () => autosaveSettings(true));
});
$("save").addEventListener("click", async () => {
  clearTimeout(saveTimer);
  await persistSettings();
  showSettings(false);
  readJob();
});

function checkManifest() {
  const m = chrome.runtime.getManifest?.();
  if (!m) return; // 测试环境
  if (m.version !== MANIFEST_NEEDED || !m.background) $("reloadBanner").hidden = false;
}

(async () => {
  checkManifest();
  await loadSettings();
  showSettings(false);
  readJob();
})();
