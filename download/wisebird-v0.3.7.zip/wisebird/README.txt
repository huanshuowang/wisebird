Wisebird 择木 — 抢先体验版 v0.3.7

安装（约 1 分钟）
1. 解压这个 zip，得到 wisebird 文件夹（装好之后不要删除或移动它）。
2. Chrome 地址栏打开 chrome://extensions，打开右上角「开发者模式」。
3. 点「加载已解压的扩展程序」，选中 wisebird 文件夹。
4. 点工具栏的 Wisebird 图标 → ⚙，粘贴简历和一个 API Key（Gemini 免费）。

更新：下载新版，用新文件夹覆盖旧的，再到 chrome://extensions 点 Wisebird 卡片上的刷新按钮 ⟳。
Key 和简历只保存在你本机的浏览器里。
