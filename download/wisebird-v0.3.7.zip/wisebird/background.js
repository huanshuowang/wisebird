// Background service worker: runs the batch analysis so it keeps going after the popup closes.
// Progress lives in chrome.storage.local ("batchJob"); the popup just renders it.
importScripts("i18n.js", "core.js");

let batchRunning = false;
let batchCancel = false;

function setBadge(job) {
  if (job.status === "running") {
    chrome.action.setBadgeBackgroundColor({ color: "#1e8e3e" });
    chrome.action.setBadgeText({ text: `${job.done}/${job.total}` });
  } else if (job.status === "done" || job.status === "cancelled") {
    chrome.action.setBadgeBackgroundColor({ color: "#1e8e3e" });
    chrome.action.setBadgeText({ text: "✓" });
  } else {
    chrome.action.setBadgeText({ text: "" });
  }
}

async function startBatch(tabs) {
  if (batchRunning) return;
  batchRunning = true;
  batchCancel = false;
  try {
    await runBatch(tabs, { isCancelled: () => batchCancel, badge: setBadge, activate: true });
  } catch (e) {
    await bgLog("ERROR(start) " + (e.stack || e.message || e));
  } finally {
    batchRunning = false;
  }
}

chrome.runtime.onMessage.addListener((msg, _sender, send) => {
  if (msg?.type === "batch:start") {
    bgLog(`got batch:start (${(msg.tabs || []).length} tabs)`);
    startBatch(msg.tabs || []);
    send({ ok: true }); // 立刻回执：让弹窗知道后台确实收到了
  } else if (msg?.type === "batch:cancel") {
    batchCancel = true;
    send({ ok: true });
  }
  return false;
});

self.addEventListener("unhandledrejection", (e) => bgLog("unhandled: " + (e.reason?.message || e.reason)));

// 装好后打开网站上的欢迎页（三步上手）；卸载时打开 30 秒的反馈问卷。两个页面都在网站上，改内容不用重新打包
const SITE = "https://huanshuowang.com/wisebird/";
chrome.runtime.onInstalled.addListener(({ reason }) => {
  if (reason === "install") chrome.tabs.create({ url: `${SITE}welcome.html?lang=${detectLang()}` });
});
chrome.runtime.setUninstallURL(`${SITE}bye.html?v=${chrome.runtime.getManifest().version}&lang=${detectLang()}`);

// service worker 被浏览器回收 / 重启后，上次没跑完的任务标成"被中断"，重新点扫描会接着做（已分析的有缓存）
(async () => {
  await bgLog("service worker started");
  const { batchJob } = await chrome.storage.local.get("batchJob");
  if (batchJob?.status === "running" && !batchRunning) {
    batchJob.status = "interrupted";
    await chrome.storage.local.set({ batchJob });
    setBadge(batchJob);
  }
})();
