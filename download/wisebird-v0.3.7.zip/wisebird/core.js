// Shared by the popup and the background service worker (no DOM access in here).
const MANIFEST_NEEDED = "0.3.7"; // 弹窗文件每次打开都会重新读取，但 manifest（后台、权限）要点 chrome://extensions 的刷新按钮才会更新：用版本号检测
const PROVIDERS = {
  deepseek: { model: "deepseek-flash", url: "https://api.deepseek.com/chat/completions" },
  openai: { model: "gpt-4o-mini", url: "https://api.openai.com/v1/chat/completions" },
  anthropic: { model: "claude-haiku-4-5-20251001", url: "https://api.anthropic.com/v1/messages" },
  gemini: { model: "gemini-3.8-flash", url: "https://generativelanguage.googleapis.com/v1beta/models/" },
};

const DEFAULT_PROFILE = "F-1 international student, using OPT/STEM OPT, will need H-1B sponsorship later";
const DEFAULT_PROFILE_NOVISA = "No work-authorization concerns (citizen, green-card holder, or applying in the home country)";
const DEFAULT_EXP_TOLERANCE = 3;

// The AI answers in the user's chosen language. Enum-like tokens ("投"/"可以试"/"不建议" etc.) stay Chinese internally
// and are translated for display, so stored history works in either language.
function buildSystem({ tol, lang, needVisa, prefs }) {
  const en = lang === "en";
  const L = (zh, e) => (en ? e : zh);
  tol = Number.isFinite(tol) ? tol : DEFAULT_EXP_TOLERANCE;
  const who = needVisa ? "an international student in the US" : "a job seeker";
  const visaSchema = needVisa
    ? `,
  "sponsor": {
    "opt":       {"status": "good|bad|unknown", "detail": "", "evidence": ""},
    "stem_opt":  {"status": "good|bad|unknown", "detail": "", "evidence": ""},
    "h1b":       {"status": "good|bad|unknown", "detail": "", "evidence": ""},
    "restriction": {"status": "bad|unknown", "detail": "", "evidence": ""},
    "company_history": {"detail": "what you genuinely recall about this company sponsoring H-1B / hiring international students, or 'no reliable knowledge'", "confidence": "low|medium|high"}
  }`
    : "";
  const visaRules = needVisa
    ? `
Sponsor rules: "good" = the posting explicitly welcomes it (OPT/CPT/STEM OPT welcome, sponsorship available, mentions E-Verify for STEM OPT). "bad" = the posting explicitly excludes it. "unknown" = not mentioned. "restriction" is "bad" only if the posting requires US citizenship, permanent residency, security clearance, or authorization to work without sponsorship. Never invent quotes.
`
    : `
The candidate does NOT need visa sponsorship. Ignore OPT / H-1B / sponsorship entirely: do not mention them, do not penalize their absence, do not output a "sponsor" object.
`;
  const redFlagVisa = needVisa ? "include requires US citizen/green card, security clearance, 'no sponsorship' when the candidate needs it, must already have work authorization without sponsorship, AND " : "";
  const blockerVisa = needVisa ? "explicit exclusion of the candidate's work-authorization situation / citizenship or clearance requirement the candidate can't meet, " : "";
  const adjustVisa = needVisa
    ? `
   - Work authorization: posting explicitly welcomes OPT/CPT/sponsorship +0.5. Visa NOT mentioned = 0, no change at all: most postings never mention it, and unless the posting explicitly says it does not sponsor / requires citizenship or existing authorization, treat it as open. Silence must never lower the score; a strong match with no visa mention can and should score 8+.`
    : "";
  return `You are a job-fit assistant for ${who}. You get the candidate's resume, their situation, optional preferences, and one job posting. Judge honestly; do not flatter, but do not be stingy either.

If the posting text looks truncated or very short, say so in the summary and do not guess missing requirements — never present a gap in the text as a gap in the job.

Reply with ONE JSON object only, no markdown, in exactly this shape. All free text must be in ${L("Simplified Chinese", "English")}, except "evidence" which must be a short verbatim quote from the posting (or "" if none). The enum values of "verdict" must stay exactly as written (Chinese).
{
  "job": {"title": "", "company": ""},
  "salary": "the pay/salary exactly as stated in the posting, keep original numbers/currency, e.g. '$70,000–$85,000/yr' or '$25-30/hr'. If the posting states no pay, use ${L("'未公开'", "'Not disclosed'")}. Never estimate or invent a number that isn't in the text.",
  "score": 0-10 (number, .5 steps allowed),
  "verdict": "投" | "可以试" | "不建议",
  "requirements": {
    "education": {
      "required": "degree level literally required by the posting, e.g. ${L("'本科' / '硕士' / '博士' / '未提及'", "'Bachelor's' / 'Master's' / 'PhD' / 'Not mentioned'")}",
      "hard_requirement": true/false (true unless the posting itself says something like 'or equivalent experience' / preferred-not-required),
      "candidate_has": "highest degree the resume actually shows, and whether it is completed or in progress",
      "meets": true/false/"unclear",
      "note": "one short sentence explaining the comparison"
    },
    "experience": {
      "required": "the years of experience the posting asks for, copied as a number or range, e.g. ${L("'5-10年' / '2年以上' / '未提及'", "'5-10 years' / '2+ years' / 'Not mentioned'")}. ALWAYS state the number if the posting gives one anywhere (including 'preferred' lines); use ${L("'未提及'", "'Not mentioned'")} only if no years or level are given at all",
      "candidate_has": "candidate's actual relevant years, estimated from resume dates",
      "meets": true/false/"unclear",
      "note": "one short sentence explaining the comparison"
    },
    "timing": {
      "required": "start date / availability the posting literally asks for, e.g. ${L("'尽快入职，全职' / '2026 届毕业生' / '2026 年夏季实习' / '未提及'", "'Immediate full-time start' / 'Class of 2026' / 'Summer 2026 internship' / 'Not mentioned'")}",
      "candidate_has": "when the candidate can actually start, from CANDIDATE AVAILABILITY or the resume's graduation date",
      "meets": true/false/"unclear",
      "note": "one short sentence explaining the comparison"
    }
  },
  "red_flags": ["short phrases; ${redFlagVisa}include education/experience/timing mismatches here too (e.g. ${L("'要求硕士，你是本科在读', '要求5-10年经验，你只有约1年'", "'Requires a Master's; you are a Bachelor's student', 'Requires 5-10 years; you have about 1'")}) whenever requirements.education.meets, requirements.experience.meets or requirements.timing.meets is false"],
  "summary": "EXACTLY 2 sentences: sentence 1 = why the candidate fits; sentence 2 = the main thing missing. If education, experience or timing requirement is not met, sentence 2 must say so explicitly.",
  "pros": ["0-3 very short phrases, each AT MOST ${L("14 characters", "28 characters")}: the strongest reasons this posting fits the candidate, e.g. ${L("'内容策略对口', '有创作者运营经历'", "'Strategy work matches', 'Creator-ops experience'")}"],
  "cons": ["0-3 very short phrases, each AT MOST ${L("14 characters", "28 characters")}: the biggest negatives or blockers, e.g. ${L("'Manager 级别', '要求硕士'", "'Manager level', 'Needs a Master's'")}. Every hard blocker listed in red_flags must also appear here"],
  "matches": ["specific resume items that match the posting"],
  "gaps": ["specific requirements the resume does not show"],
  "jd_points": ["5-8 key points of the posting condensed into plain ${L("Chinese", "English")}: what the job does, must-have skills, level, location, pay if stated"]${visaSchema},
  "company": {
    "headcount": {"estimate": "a rough size bucket from your training knowledge, e.g. ${L("'10,000+ 人' / '51-200 人' / '未知'", "'10,000+' / '51-200' / 'Unknown'")}; use ${L("'未知'", "'Unknown'")} if you are not genuinely confident about this specific company", "confidence": "low|medium|high"},
    "review_impression": {
      "status": "positive|mixed|negative|unknown",
      "note": "ONE short sentence on the general themes you genuinely recall being associated with this company as an employer (pay / work-life balance / management / culture), or '' if unknown",
      "confidence": "low|medium|high"
    },
    "scam_check": {
      "status": "clean|suspicious|unclear",
      "reasons": ["short phrases, only concrete signals actually present in THIS posting's text, each paired with why it's suspicious"],
      "evidence": "a short verbatim quote from the posting backing the top reason, or \"\" if status is clean"
    }
  }
}
${visaRules}
Company scam_check rules (based only on THIS posting's actual text, never guess): set "suspicious" only if concrete signals are present, such as — asks the candidate to pay for training/equipment/background-check fees upfront, mentions checks/wire transfers/reshipping/mystery-shopper tasks, asks for bank account or SSN/ID before any interview, contact is only a personal Gmail/WhatsApp/Telegram instead of a verifiable company domain, pay is wildly high for minimal-skill/no-experience work with vague duties, "no interview needed / start today / limited spots" urgency pressure, or a well-known company name paired with a posting that reads inconsistent with how that company normally hires. Set "clean" when none of that is present (the large majority of normal postings from real companies are "clean" — do not manufacture suspicion out of ordinary corporate boilerplate). Set "unclear" only if the posting text is too thin to judge. Never call a posting suspicious just because you don't recognize the company.

Company review_impression rules: this is NOT real Glassdoor/Indeed data — you have no live internet access, so never state a specific numeric rating, never invent a specific quoted review, and never claim a stat you cannot source from training knowledge. Only give a rough qualitative bucket plus at most one plain sentence about generally-known themes. Use "unknown" with empty note whenever you are not genuinely confident — that is the common, expected case.

Education/experience gate (apply BEFORE picking the verdict):
- Read the resume carefully for the candidate's actual highest completed/in-progress degree and actual years of relevant experience (count internships as experience but note they are not full-time).
- If the posting states a degree level as a hard requirement (no "or equivalent experience" escape clause) and the candidate's degree is lower (e.g. posting wants Master's/PhD, candidate is a Bachelor's student), set requirements.education.meets = false. This is a real blocker: verdict must NOT be "投", and should normally be "不建议" unless the JD signals flexibility ("or equivalent experience", "currently pursuing", open to new grads) — then hard_requirement = false and meets can be true/unclear.
- Experience gate uses a ${tol}-year tolerance window: gap = (posting's minimum required years) - (candidate's actual relevant years; internships count as real years). If gap <= ${tol} (including 0 years against a posting asking up to ${tol}), this is NOT a hard blocker — set meets = true (or "unclear" if vague), do not add it to red_flags, and do not let it push the verdict to "不建议" by itself. Example: with ${tol}-year tolerance, 4 years vs a posting asking "${4 + tol} years" has gap ${tol}, meets = true. Only when gap > ${tol} set meets = false — a real blocker: verdict must NOT be "投", and should normally be "不建议".
- Timing gate (same weight as the degree gate): compare when the posting needs someone (immediate / ASAP / within weeks, a specific start date, a graduating class or season such as "Class of 2026" or "Summer 2026") with when the candidate can actually start (CANDIDATE AVAILABILITY first, otherwise the graduation date on the resume). If the candidate cannot be available in that window — e.g. still a student until 2027 while the role needs a full-time hire now, or it is for the class of 2025/2026 — set requirements.timing.meets = false: a real blocker, verdict must NOT be "投" and should normally be "不建议", and say so in red_flags, cons and summary. A part-time or in-semester internship the candidate can really do while studying is not a mismatch. Only mark timing "unclear" when the posting states no timing; then it is neutral — never a deduction.
- If both requirements are clearly met or unspecified, they don't by themselves block a "投".
- Never quietly downgrade a hard-requirement mismatch to "可以试" without saying so in red_flags and in summary's second sentence.

Scoring — use the WHOLE 0–10 range; do not cluster at 5.5–6.5.
1) Score ROLE FIT first, 0–10. Anchors: 9–10 near-perfect match for skills, level and field; 8–8.5 strong fit with minor gaps; 7–7.5 good fit with a few real gaps; 5.5–6.5 partial fit / a stretch; 4–5 weak; below 4 poor. A posting that matches the candidate's field, level and main skills deserves 8+; do not hold it at 6.5 "to be safe".
2) Then adjust, never more than 1 point down in total, and only for things the posting explicitly states:${adjustVisa}
   - Salary clearly below the candidate's stated minimum -1 (salary not stated: no change).
   - Clearly misses the candidate's stated preferences -0.5 to -1. Preferences that the posting simply doesn't mention are not misses.
3) Hard blockers are enforced, not optional: one failed gate caps the score at 4.5, two or more failed gates cap it at 3.5, and the verdict must be "不建议". Hard blockers: ${blockerVisa}failed education/experience/timing gate as defined above, or a scam. Missing information (visa, salary, level, anything the posting simply doesn't say) is neutral: it is never a blocker and never a deduction. Only what the posting explicitly states can lower the score.
Verdict: score >= 7.5 and no blocker -> "投". 5 to 7 -> "可以试". Below 5, or any hard blocker -> "不建议". The verdict must agree with the score and the gate above.${prefs ? `\n\nCANDIDATE PREFERENCES (soft, only for the adjustments in step 2): ${prefs}` : ""}`;
}

const DEFAULT_SCAN_CRITERIA = "Mid/large company, early-career program, relevant to my experience";

// Pre-screen: ONE request for every card. Returns structured fields so the list can show what was actually screened.
function buildQuickScanSystem({ criteria, profile, lang, needVisa, minSalary }) {
  const en = lang === "en";
  const L = (zh, e) => (en ? e : zh);
  return `You are doing a FAST first-pass filter over a job-search RESULTS LIST (LinkedIn, Handshake or similar). You only get each card's raw visible text (title, company, location, sometimes a salary range or posting age), never the full job description. You cannot verify ${needVisa ? "sponsorship/OPT, " : ""}exact salary, or real fit from this alone — that needs the full posting, checked later. Your job here is only to weed out postings that are obviously wrong (wrong seniority, wrong field, clearly below the stated salary when a number IS shown) and flag the rest as worth a closer look.

CANDIDATE'S SCREENING CRITERIA: ${criteria || DEFAULT_SCAN_CRITERIA}
CANDIDATE'S SITUATION: ${profile || (needVisa ? DEFAULT_PROFILE : DEFAULT_PROFILE_NOVISA)}${minSalary ? `\nMINIMUM ANNUAL SALARY: $${minSalary} (hourly pay × 2080 h/year)` : ""}

Reply with ONE JSON object only, no markdown:
{"results": [{"url": "", "title": "job title from the card", "company": "company name from the card", "location": "city/state or Remote, '' if not shown", "salary": "pay exactly as shown on the card, '' if none shown", "quick_verdict": "打开看看" | "大概率不行" | "信息不够", "reason": "one short ${L("Chinese", "English")} sentence, cite what's actually in the card text"}]}
One entry per url given, in the same order. Do not invent a title, company or salary that isn't in the card text. Rules:
- "大概率不行" ONLY when the card text itself clearly contradicts the criteria (e.g. explicitly senior/staff/director level when the candidate wants early-career, a field totally unrelated to the resume, or a salary shown that is clearly below the stated minimum). Skip anything that is not a real job card (page navigation, ads).
- When the card doesn't show enough to judge something (most commonly: no salary shown${needVisa ? ", or sponsorship can't be known from a card" : ""}), do NOT penalize for that missing info — default to "打开看看" or "信息不够". Favor false positives over false negatives; the real check happens later on the full posting.
- Company size: judge only from whether you genuinely recognize the company as mid/large, or the card says so; never invent a size — unknown size is neutral.
- "reason" must be ONE short sentence, concrete and specific to that card's text, not generic boilerplate.`;
}

let cfg = {};

const store = {
  get: () => chrome.storage.local.get(["provider", "apiKey", "model", "resume", "profile", "expTolerance", "scanCriteria", "uiLang", "needVisa", "minSalary", "availability"]),
  set: (o) => chrome.storage.local.set(o),
};
const wantsVisa = (c) => c.needVisa !== false; // default on: Wisebird is built for international students

// ---------- page extraction (runs inside the tab) ----------
// 读取当前页面里的岗位正文。要自包含（会被注入到页面里执行）。
// 不再依赖各网站会改版的 class 名，按下面顺序找，找到哪种就用哪种，并把"怎么读到的"带回弹窗：
//  1) 页面里的结构化岗位数据（JSON-LD JobPosting，很多公司官网 / 招聘系统都有，连薪资都带着）
//  2) 「About the job / Job description / 职位描述」这类标题，往上找到装着正文的那一块
//  3) 按正文特征（职责、要求、福利……这些词的密度）自动挑最像岗位描述的区块
//  4) 老办法：已知网站的 class；5) 整个页面兜底
async function extractJob() {
  // 有的站只渲染描述的前几百字，点「More」才把剩下的放进页面（Handshake：点之前 454 字，点之后 2614 字）。
  // 先点开这类「展开全文」按钮再读。只认按钮上可见的字正好是 More / Show more / 展开 之类，
  // 菜单（aria-haspopup）、导航、"Show more jobs" 这种带别的词的都不点
  const EXPAND = /^(\.{3}|…)?\s*(more|show more|see more|read more|view more|显示更多|展开(全文)?|查看更多|更多)$/i;
  const expanders = [...document.querySelectorAll("button,[role=button]")].filter((b) => {
    const label = (b.innerText || "").trim();
    if (!label || label.length > 24 || !EXPAND.test(label)) return false;
    if (b.closest("nav,header,footer,aside,[role=menu],[role=listbox],[role=navigation]")) return false;
    if (b.getAttribute("aria-haspopup") || b.getAttribute("aria-expanded") === "true") return false;
    return !!(b.offsetWidth || b.offsetHeight || b.getClientRects().length);
  }).slice(0, 6);
  if (expanders.length) {
    const before = (document.body.textContent || "").length;
    expanders.forEach((b) => { try { b.click(); } catch {} });
    // 等页面把展开的文字渲染出来（后台标签页的定时器会被放慢，所以按字数变化判断，最多等 1.5 秒）
    for (let i = 0; i < 10; i++) {
      await new Promise((r) => setTimeout(r, 150));
      if ((document.body.textContent || "").length > before + 50) { await new Promise((r) => setTimeout(r, 150)); break; }
    }
  }
  const clean = (t) => (t || "").replace(/\r/g, "").replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim();
  const stripOnce = (html) => {
    const d = document.createElement("div");
    d.innerHTML = String(html);
    d.querySelectorAll("br,p,li,div,h1,h2,h3,h4,ul,ol").forEach((e) => e.insertAdjacentText("afterend", "\n"));
    return clean(d.textContent);
  };
  // 有的站（LinkedIn）把 HTML 转义了两层，解一次后还剩字面的标签，再解一次
  const stripHtml = (html) => {
    let t = stripOnce(html);
    if (/<\/?[a-z][^>]*>/i.test(t)) t = stripOnce(t);
    return t;
  };
  const first = (sels) => {
    for (const s of sels) {
      const el = document.querySelector(s);
      if (el && el.innerText && el.innerText.trim().length > 20) return el;
    }
    return null;
  };
  const txt = (sels) => {
    for (const s of sels) {
      const el = document.querySelector(s);
      if (el && el.innerText.trim()) return el.innerText.trim();
    }
    return "";
  };
  const MAX = 14000;
  const done = (method, text, extra = {}) => {
    text = clean(text);
    return {
      url: location.href,
      pageTitle: document.title,
      title: extra.title || "",
      company: extra.company || "",
      text: text.length > MAX ? text.slice(0, MAX) : text,
      method,
    };
  };
  const oldTitle = txt([".job-details-jobs-unified-top-card__job-title", ".jobs-unified-top-card__job-title", '[data-hook="job-title"]', "h1"]);
  const oldCompany = txt([".job-details-jobs-unified-top-card__company-name", ".jobs-unified-top-card__company-name", '[data-hook="employer-name"]']);

  // 页面上出现的薪资文字（LinkedIn 的薪资在顶部卡片，不在正文里）。
  // 先在读到的岗位块里找；块里没有才看整页，并注明可能属于列表里的其他岗位（Handshake 左栏全是别的岗位薪资）
  const SALARY_RE = /\$\s?\d[\d,]*(?:\.\d+)?\s?[Kk]?(?:\s?\/\s?(?:yr|year|hr|hour))?\s?(?:-|–|—|to)\s?\$?\s?\d[\d,]*(?:\.\d+)?\s?[Kk]?(?:\s?\/\s?(?:yr|year|hr|hour))?/g;
  const salaryHints = (blockText = "") => {
    const own = [...new Set(blockText.match(SALARY_RE) || [])].slice(0, 3);
    if (own.length) return "Salary text in this posting: " + own.join(" | ");
    const scope = (document.querySelector("main") || document.body).innerText || "";
    const hits = [...new Set(scope.match(SALARY_RE) || [])].slice(0, 3);
    return hits.length ? "Salary text elsewhere on the page (may belong to other postings in a list): " + hits.join(" | ") : "";
  };

  // 1) JSON-LD JobPosting
  try {
    for (const sc of document.querySelectorAll('script[type="application/ld+json"]')) {
      let data;
      try { data = JSON.parse(sc.textContent); } catch { continue; }
      const stack = Array.isArray(data) ? [...data] : [data];
      while (stack.length) {
        const n = stack.shift();
        if (!n || typeof n !== "object") continue;
        if (n["@graph"]) stack.push(...[].concat(n["@graph"]));
        if (![].concat(n["@type"] || []).includes("JobPosting") || !n.description) continue;
        const desc = stripHtml(n.description);
        if (desc.length < 300) continue;
        const org = n.hiringOrganization && (n.hiringOrganization.name || (typeof n.hiringOrganization === "string" ? n.hiringOrganization : ""));
        const loc = [].concat(n.jobLocation || []).map((l) => l && l.address && [l.address.addressLocality, l.address.addressRegion].filter(Boolean).join(", ")).filter(Boolean).join(" | ");
        let sal = "";
        const v = n.baseSalary && n.baseSalary.value;
        if (v) sal = `${n.baseSalary.currency || ""} ${v.minValue ?? v.value ?? ""}${v.maxValue ? " - " + v.maxValue : ""} ${v.unitText || ""}`.trim();
        const head = [
          n.title && "Title: " + n.title,
          org && "Company: " + org,
          loc && "Location: " + loc,
          n.employmentType && "Type: " + [].concat(n.employmentType).join(", "),
          sal && "Salary (structured data): " + sal,
        ].filter(Boolean).join("\n");
        return done("jsonld", head + "\n\n" + desc, { title: n.title || oldTitle, company: org || oldCompany });
      }
    }
  } catch (e) { /* fall through */ }

  // 2) 「About the job」这类标题 -> 往上找装正文的块
  try {
    const HEAD = /^(about\s+(the\s+)?(job|role|position|opportunity)|about\s+this\s+(job|role|position)|job\s+description|position\s+(summary|description)|role\s+description|关于(本|该)?(职位|岗位)|职位描述|岗位职责|工作描述)\s*[:：]?$/i;
    const visible = (e) => !!(e.offsetWidth || e.offsetHeight || e.getClientRects().length);
    let head = null;
    for (const e of document.querySelectorAll("body *")) {
      // 按去掉空白后的长度算：LinkedIn 的「About the job」前后各有一串换行和空格，原始长度 41，以前会被跳过
      const t = (e.textContent || "").trim();
      if (!t || t.length > 40 || e.children.length > 1) continue;
      if (HEAD.test(t) && visible(e)) { head = e; break; }
    }
    if (head) {
      let el = head, best = null;
      for (let i = 0; i < 14 && el.parentElement && el.parentElement !== document.body; i++) {
        el = el.parentElement;
        const len = (el.innerText || "").length;
        if (len > 22000) break;
        if (len >= 700) { best = el; break; }
      }
      if (best) {
        // 描述常被拆成并列的几块（About / Responsibilities / Qualifications…），上面只找到了第一块：
        // 继续往上长，直到碰到页头 / 导航、"相似岗位"之类的无关内容，或长度暴涨
        const NOISE = /(similar jobs|people also viewed|jobs you may be interested in|more jobs|meet the hiring team|job search faster with premium|show more jobs)/i;
        // Handshake：标题、At a glance、「What they're looking for」（工作授权、专业、毕业时间）和描述是并列的几块，
        // 最后才是 Similar Jobs，所以继续往上长、在 Similar Jobs 处截断。别的站（LinkedIn）照旧碰到就停：
        // 再往上会把 Premium 的申请人图表之类读进来
        const cutBelow = /(^|\.)joinhandshake\.com$/.test(location.hostname);
        let bestText = best.innerText || "";
        for (let i = 0; i < 8 && best.parentElement && best.parentElement !== document.body; i++) {
          const p = best.parentElement;
          let pt = p.innerText || "";
          const cut = pt.search(NOISE);
          if (cut >= 0) {
            const at = pt.indexOf(bestText.slice(0, 80));
            if (!cutBelow || at < 0 || at > cut) break;
            pt = pt.slice(0, cut);
          }
          if (pt.length > 18000 || pt.length > bestText.length * 4) break;
          if (p.matches("nav,header,footer,aside,main,[role=main]") || p.querySelector("nav,header,footer,aside")) break;
          best = p;
          bestText = pt;
        }
        // 页面最上面的 h1 可能只是栏目名（Handshake 是「Jobs」），岗位块里自己的 h1 才是职位名
        const ownH1 = best.querySelector("h1");
        const h1 = ((ownH1 || document.querySelector("h1")) || {}).innerText || "";
        const sal = salaryHints(bestText);
        return done("heading", [`PAGE TITLE: ${document.title}`, h1 && `HEADING: ${h1}`, sal, "", bestText].filter((x) => x !== false && x !== undefined && x !== null).join("\n"), { title: (ownH1 && h1.trim()) || oldTitle || h1, company: oldCompany });
      }
    }
  } catch (e) { /* fall through */ }

  // 3) 按正文特征挑最像岗位描述的区块
  try {
    const KW = /(responsibilit|qualification|requirement|what you(?:’|')?ll|who you are|you will|experience|benefits|compensation|salary|equal opportunity|about (?:the )?(?:role|job|team)|职责|要求|福利)/gi;
    let bestEl = null, bestScore = 0, n = 0;
    for (const el of document.querySelectorAll("main,article,[role=main],section,div")) {
      if (++n > 1800) break;
      if (el.children.length < 1) continue;
      const t = el.innerText;
      if (!t) continue;
      const len = t.length;
      if (len < 700 || len > 25000) continue;
      const hits = (t.match(KW) || []).length;
      if (hits < 2) continue;
      const score = hits * 60 - len / 80;
      if (score > bestScore) { bestScore = score; bestEl = el; }
    }
    if (bestEl) return done("scored", [`PAGE TITLE: ${document.title}`, salaryHints(bestEl.innerText), "", bestEl.innerText].join("\n"), { title: oldTitle, company: oldCompany });
  } catch (e) { /* fall through */ }

  // 4) 老办法：已知网站的 class
  const host = location.hostname;
  let pane = null;
  if (host.includes("linkedin.com")) {
    pane = first([".jobs-search__job-details--container", ".jobs-details", ".job-view-layout", ".scaffold-layout__detail", ".jobs-description"]);
  } else if (host.includes("joinhandshake.com")) {
    pane = first(['[data-hook="details-pane"]', '[data-hook="job-details"]', '[class*="details"]']);
  }
  if (pane && pane.innerText.trim().length >= 400) return done("selector", pane.innerText, { title: oldTitle, company: oldCompany });

  // 5) 兜底：整个页面
  const fallback = first(["main", "article"]) || document.body;
  return done("body", fallback.innerText, { title: oldTitle, company: oldCompany });
}

// ---------- 读取"当前已经加载出来的" LinkedIn 搜索结果列表页 ----------
// 只读这一屏已经渲染出来的卡片，不点击、不翻页、不追加搜索。
// 用 href 里稳定的 "/jobs/view/" 而不是具体 class 名去定位卡片，class 名换皮也不受影响。
function extractSearchResults() {
  const seen = new Set();
  const results = [];
  const cleanText = (el) => {
    const lines = el.innerText.split("\n").map((l) => l.trim()).filter((l) => l && !/^skip to .*content$/i.test(l));
    // 卡片里可见文字和无障碍文字经常重复同一行，去掉相邻重复行减少噪音
    return lines.filter((l, i) => l !== lines[i - 1]).join("\n");
  };
  const push = (url, el) => {
    const cardText = cleanText(el);
    if (cardText.length < 5) return false;
    results.push({ url, cardText: cardText.slice(0, 600) });
    return true;
  };

  // 方案一：2026 年新版 LinkedIn —— componentkey="job-card-component-ref-{职位ID}" 的 div（不是真链接）
  document.querySelectorAll('[componentkey^="job-card-component-ref-"]').forEach((el) => {
    const key = el.getAttribute("componentkey");
    const m = key.match(/(\d+)$/);
    if (!m || seen.has(m[1])) return;
    if (push(`https://www.linkedin.com/jobs/view/${m[1]}/`, el)) seen.add(m[1]);
  });

  // 方案二：老版 LinkedIn 的懒加载属性
  if (results.length < 3) {
    document.querySelectorAll("[data-occludable-job-id]").forEach((el) => {
      const id = el.getAttribute("data-occludable-job-id");
      if (!id || seen.has(id)) return;
      if (push(`https://www.linkedin.com/jobs/view/${id}/`, el)) seen.add(id);
    });
  }

  // 方案三（通用，Handshake 等）：找指向"某个岗位详情"的链接，再往上找"只包含这一个岗位"的最大区块当作卡片
  const JOB_HREF = /\/(?:jobs\/view|jobs|job-search|stu\/jobs|job|postings?)\/(?:[^\/?#]*?-)?(\d{5,})(?:[\/?#]|$)/i;
  const idOf = (a) => {
    try {
      const m = new URL(a.getAttribute("href"), location.href).pathname.match(JOB_HREF);
      return m ? m[1] : null;
    } catch { return null; }
  };
  const anchors = Array.from(document.querySelectorAll("a[href]")).map((a) => [a, idOf(a)]).filter(([, id]) => id);
  if (results.length < 3) {
    const idsIn = (root) => new Set(anchors.filter(([a]) => root.contains(a)).map(([, id]) => id));
    // 页头/导航/无障碍跳转文字不是岗位内容
    const NOISE = /^(skip to (main )?content|skip to .*|跳到.*内容|跳至.*内容)$/i;
    const LANDMARK = "nav, header, aside, main, [role=navigation], [role=banner], [role=main]";
    const cardFor = (a) => {
      let el = a, inList = false;
      while (el.parentElement && el.parentElement !== document.body) {
        const p = el.parentElement;
        if (idsIn(p).size > 1) {
          // 真正的列表：父节点下有 ≥2 个并排、且各自只含一个岗位的子节点
          inList = Array.from(p.children).filter((c) => idsIn(c).size === 1).length >= 2;
          break;
        }
        // 右侧详情面板常带着"当前选中岗位"的同一个链接：不能因此把整页当成一张卡片
        if (p.matches(LANDMARK) || p.querySelector(LANDMARK) || p.innerText.length > 900) break;
        el = p;
      }
      return { el, inList };
    };
    const textOf = (el) => el.innerText.split("\n").map((l) => l.trim()).filter((l) => l && !NOISE.test(l));
    // 同一个岗位 id 可能有好几个链接（列表卡片 + 详情面板）：取文字最少、但足够像一张卡片的那个
    const byId = new Map();
    for (const [a, id] of anchors) {
      if (seen.has(id)) continue;
      if (!byId.has(id)) byId.set(id, []);
      byId.get(id).push(a);
    }
    for (const [id, list] of byId) {
      let best = null;
      for (const a of list) {
        const { el, inList } = cardFor(a);
        const lines = textOf(el);
        if (lines.join(" ").length < 12 || lines.length < 2) continue; // 只有一行（链接文字/导航）不算卡片
        const len = lines.join("").length;
        // 优先"和别的岗位卡片并排"的列表卡片（带公司/地点/薪资），其次才是文字最少的那个
        if (!best || (inList && !best.inList) || (inList === best.inList && len < best.len)) best = { a, el, len, inList };
      }
      if (!best) continue;
      const url = new URL(best.a.getAttribute("href"), location.href).href.split("#")[0];
      if (push(url, best.el)) seen.add(id);
    }
  }

  // 诊断：读不到时能看出这个网站的岗位链接长什么样
  const sampleHrefs = [...new Set(Array.from(document.querySelectorAll("a[href]")).map((a) => a.getAttribute("href")).filter((h) => /job|posting|position/i.test(h || "")).map((h) => h.replace(/\d{4,}/g, "N").slice(0, 70)))].slice(0, 4);
  return {
    pageTitle: document.title,
    url: location.href,
    results: results.slice(0, 40),
    debug: {
      componentKeyEls: document.querySelectorAll('[componentkey^="job-card-component-ref-"]').length,
      occludableEls: document.querySelectorAll("[data-occludable-job-id]").length,
      jobLinks: anchors.length,
      host: location.hostname,
      sampleHrefs,
    },
  };
}

// ---------- LLM calls ----------
async function callLLM(system, user) {
  const p = PROVIDERS[cfg.provider];
  // DeepSeek 已停用 deepseek-chat 这个名字（2026-07-24），设置里手填过的旧名也走新默认
  const model = (cfg.provider === "deepseek" && cfg.model === "deepseek-chat") ? p.model : (cfg.model || p.model);
  let res, data;
  if (cfg.provider === "anthropic") {
    res = await fetch(p.url, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": cfg.apiKey,
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true",
      },
      body: JSON.stringify({ model, max_tokens: 2500, temperature: 0.2, system, messages: [{ role: "user", content: user }] }),
    });
    data = await res.json();
    if (!res.ok) throw new Error(data?.error?.message || res.statusText);
    return data.content.map((c) => c.text || "").join("");
  }
  if (cfg.provider === "gemini") {
    res = await fetch(`${p.url}${encodeURIComponent(model)}:generateContent`, {
      method: "POST",
      headers: { "content-type": "application/json", "x-goog-api-key": cfg.apiKey },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: system }] },
        contents: [{ role: "user", parts: [{ text: user }] }],
        generationConfig: { temperature: 0.2, responseMimeType: "application/json" },
      }),
    });
    data = await res.json();
    if (!res.ok) throw new Error(data?.error?.message || res.statusText);
    return data.candidates[0].content.parts.map((x) => x.text || "").join("");
  }
  // OpenAI-compatible (DeepSeek, OpenAI)
  res = await fetch(p.url, {
    method: "POST",
    headers: { "content-type": "application/json", authorization: `Bearer ${cfg.apiKey}` },
    body: JSON.stringify({
      model,
      temperature: 0.2,
      response_format: { type: "json_object" },
      // deepseek-flash 默认开思考模式：慢、贵，还会忽略 temperature；打分只要 JSON，关掉
      ...(cfg.provider === "deepseek" ? { thinking: { type: "disabled" } } : {}),
      messages: [
        { role: "system", content: system },
        { role: "user", content: user },
      ],
    }),
  });
  data = await res.json();
  if (!res.ok) throw new Error(data?.error?.message || res.statusText);
  return data.choices[0].message.content;
}

function parseJSON(s) {
  const start = s.indexOf("{");
  if (start < 0) throw new Error(t("err.nojson") + s.slice(0, 300));
  let depth = 0, inStr = false, esc = false;
  for (let i = start; i < s.length; i++) {
    const ch = s[i];
    if (inStr) {
      if (esc) esc = false;
      else if (ch === "\\") esc = true;
      else if (ch === '"') inStr = false;
    } else if (ch === '"') inStr = true;
    else if (ch === "{") depth++;
    else if (ch === "}" && --depth === 0) {
      try {
        return JSON.parse(s.slice(start, i + 1));
      } catch (e) {
        throw new Error(t("err.badjson") + e.message + "\n" + s.slice(0, 300));
      }
    }
  }
  throw new Error(t("err.trunc") + s.slice(0, 300));
}

const verdictKey = (v) => (/^(投|go)$/i.test(String(v).trim()) ? "go" : /^(可以试|maybe|try)$/i.test(String(v).trim()) ? "try" : "no");
const NOSAL = /^(未公开|未提及|未知|n\/a|none|-|—|not (disclosed|stated|specified|listed|provided|mentioned)|undisclosed|unknown)$/i;
const hasSalary = (s) => !!s && !NOSAL.test(String(s).trim());

// "$120-160K/yr" · "$34/hr" · "$70,000–$85,000" -> highest annual USD figure, or null when it can't be read confidently
function parseSalary(str) {
  const s = String(str || "");
  if (!s || /[¥€£₹]|\b(?:CAD|EUR|GBP|CA\$|C\$|AUD)\b/i.test(s)) return null;
  const nums = [...s.matchAll(/\$?\s*(\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?)\s*([kK])?/g)].map((m) => {
    let v = parseFloat(m[1].replace(/,/g, ""));
    if (m[2]) v *= 1000;
    return v;
  }).filter((v) => v > 0);
  if (!nums.length || !/\$|usd/i.test(s)) return null;
  let hi = Math.max(...nums);
  if (/\/\s*h(?:ou)?r|per hour|hourly|an hour/i.test(s)) hi *= 2080;
  else if (/\/\s*mo(?:nth)?\b|per month|monthly/i.test(s)) hi *= 12;
  else if (hi < 1000) return null; // a bare small number with no unit is too ambiguous
  return Math.round(hi);
}
const belowMin = (salaryStr) => {
  const min = Number(cfg.minSalary);
  const v = parseSalary(salaryStr);
  return min > 0 && v != null && v < min;
};

// ---------- 读取一个标签页里的岗位：在"所有框架"里都跑一遍，挑最像岗位正文的那个 ----------
// 很多公司官网的招聘页只是个壳，真正的岗位（Greenhouse / Lever / Ashby 等）嵌在 iframe 里。
const METHOD_RANK = { jsonld: 4, heading: 3, scored: 2, selector: 2, body: 0 };
async function cachedFor(job) {
  const key = jobKey(job.url);
  const c = (await cacheGetAll())[key];
  // 有缓存但之后改过设置：旧结果照样显示（标明是旧的），由用户决定要不要重新分析；不再直接当成"没分析过"
  if (c) return { ...c, stale: c.sig !== cfgSig() };
  // 升级前分析过的岗位还没有缓存，但"收藏"里有完整结果：直接拿来用
  const { history = [] } = await chrome.storage.local.get("history");
  const h = history.find((x) => x.result && jobKey(x.url) === key);
  return h ? { r: h.result, job: h.job, ts: h.ts, legacy: true } : null;
}

const THIN_CHARS = 1200; // 真实岗位描述很少短于这个；更短多半是没读全
// "读到的是不是岗位描述正文"：光看字数不行（页面外壳也有一千多字），要看有没有职责 / 要求 / 资格这类内容
const JD_ANY = /(responsibilit|qualification|requirement|about the (?:job|role|team|position)|what you(?:’|')?ll|you will|who you are|benefits|bachelor|years? of|skills|experience|equal opportunity|职责|要求|任职)/gi;
const JD_CORE = /(responsibilit|qualification|requirement|about the (?:job|role|team|position)|what you(?:’|')?ll|you will|who you are|职责|任职|岗位要求)/i;
function jdLike(j) {
  if (!j || !j.text || j.text.length < 700) return false;
  const hits = new Set((j.text.match(JD_ANY) || []).map((x) => x.toLowerCase()));
  return JD_CORE.test(j.text) && hits.size >= 3;
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
// opts.activate：后台标签页（LinkedIn 等）不显示出来就不渲染岗位正文——读不到时临时切过去，读完立刻切回原来的标签页
async function readTabJobPatient(tab, opts = {}) {
  let best = null;
  const attempt = async () => {
    const j = await readTabJob(tab);
    if (!j) return;
    if (!best || (jdLike(j) && !jdLike(best)) || (jdLike(j) === jdLike(best) && j.text.length > best.text.length)) best = j;
  };
  for (let i = 0; i < 3; i++) {
    try {
      const tb = await chrome.tabs.get(tab.id);
      if (tb.status && tb.status !== "complete") { await sleep(1500); continue; }
    } catch { break; }
    await attempt();
    if (jdLike(best)) break;
    await sleep(2000); // 后台标签页的内容有时要过一会儿才渲染出来
  }
  if (!jdLike(best) && opts.activate) {
    let prev = null;
    try {
      const tb = await chrome.tabs.get(tab.id);
      [prev] = await chrome.tabs.query({ active: true, windowId: tb.windowId });
      await chrome.tabs.update(tab.id, { active: true });
      await sleep(3000);
      await attempt();
    } catch {} finally {
      try { if (prev && prev.id !== tab.id) await chrome.tabs.update(prev.id, { active: true }); } catch {}
    }
  }
  if (best) {
    best.thin = best.text.length < THIN_CHARS;
    best.noBody = !jdLike(best);
  }
  return best;
}
async function readTabJob(tab) {
  const res = await chrome.scripting.executeScript({ target: { tabId: tab.id, allFrames: true }, func: extractJob });
  const cands = res.map((x) => x.result).filter((x) => x && x.text);
  if (!cands.length) return null;
  const score = (j) => (j.text.length < 200 ? -1 : (METHOD_RANK[j.method] ?? 0) * 100000 + j.text.length);
  const best = cands.reduce((a, b) => (score(b) > score(a) ? b : a));
  // 链接、缓存都用标签页本身的地址：嵌入框架的地址单独打开只是个空壳
  return { ...best, url: tab.url || best.url, frameUrl: best.url };
}


// 硬性条件（学历 / 经验 / 入职时间）只要有不符的，就由程序强制封顶分数并判"不建议"。
// 不能只靠提示词：模型有时会一边把条件标成不符，一边仍给 6.5 分、判"可以试"。
const isFalse = (v) => v === false || String(v).toLowerCase() === "false";
function enforceGates(r) {
  const q = r?.requirements || {};
  const failed = [];
  if (isFalse(q.education?.meets) && q.education.hard_requirement !== false && String(q.education.hard_requirement).toLowerCase() !== "false") failed.push("education");
  if (isFalse(q.experience?.meets)) failed.push("experience");
  if (isFalse(q.timing?.meets)) failed.push("timing");
  if (!failed.length) return r;
  const cap = failed.length >= 2 ? 3.5 : 4.5;
  const sc = Number(r.score);
  return { ...r, score: Number.isFinite(sc) ? Math.min(sc, cap) : cap, verdict: "不建议", gate_failed: failed };
}

function preferencesText() {
  const parts = [];
  if (cfg.scanCriteria) parts.push(cfg.scanCriteria);
  if (Number(cfg.minSalary) > 0) parts.push(`minimum annual salary $${Number(cfg.minSalary)}`);
  return parts.join("; ");
}

async function runAnalysis(job) {
  const needVisa = wantsVisa(cfg);
  const user =
    `CANDIDATE SITUATION:\n${cfg.profile || (needVisa ? DEFAULT_PROFILE : DEFAULT_PROFILE_NOVISA)}\n\n` +
    (cfg.availability ? `CANDIDATE AVAILABILITY (when they can start):\n${cfg.availability}\n\n` : "") +
    `RESUME:\n${cfg.resume}\n\n` +
    `JOB POSTING (page title: ${job.pageTitle}; detected title: ${job.title}; detected company: ${job.company}; url: ${job.url}):\n${job.text}`;
  const tol = parseFloat(cfg.expTolerance);
  const raw = await callLLM(buildSystem({ tol: Number.isFinite(tol) ? tol : DEFAULT_EXP_TOLERANCE, lang: UI_LANG, needVisa, prefs: preferencesText() }), user);
  let r = enforceGates(parseJSON(raw));
  if (!r.job?.company && job.company) (r.job = r.job || {}).company = job.company;
  if (!r.job?.title && job.title) (r.job = r.job || {}).title = job.title;
  return r;
}

// 只留档"值得投"和"可以试"两个档位，"不建议"不存，省得收藏里全是不想投的岗位。
async function saveToHistory(r, job) {
  const key = verdictKey(r.verdict);
  if (key === "no") return;
  const rec = {
    id: (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`),
    url: job.url,
    title: r.job?.title || job.title || job.pageTitle || "",
    company: r.job?.company || job.company || "",
    score: r.score,
    verdict: r.verdict,
    tier: key,
    salary: r.salary || "",
    ts: Date.now(),
    result: r, // 存完整结果，收藏里点开才能看到和刚分析完一样的详细面板
    job: { url: job.url, title: job.title, company: job.company, pageTitle: job.pageTitle },
  };
  const { history = [] } = await chrome.storage.local.get("history");
  const filtered = history.filter((h) => h.url !== rec.url); // 同一个链接重新分析过，用新结果替换旧记录
  filtered.unshift(rec);
  await chrome.storage.local.set({ history: filtered.slice(0, 300) });
}

// ---------- 已分析岗位的缓存：同一个岗位不重复调用 AI；弹窗关掉后结果也不会丢 ----------
// key：站点 + 岗位 id（LinkedIn 的 currentJobId、/jobs/view/123、Handshake 的 /jobs/123 都认），没有 id 就用路径
function jobKey(url) {
  try {
    const u = new URL(url);
    let id = (u.pathname.match(/(\d{5,})/) || [])[1];
    for (const k of ["currentJobId", "gh_jid", "jobId", "job_id", "jid", "jk", "vjk", "requisitionId", "gh_src_jid"]) id = u.searchParams.get(k) || id;
    // 找不到岗位 id 时带上 query：宁可认不出是同一个，也不能让不同岗位共用一个 key
    return u.hostname.replace(/^www\./, "") + (id ? "#" + id : u.pathname + u.search);
  } catch { return String(url); }
}
// 简历 / 身份 / 标准 / 语言一变，旧结果就不能再用
function cfgSig() {
  const x = [UI_LANG, wantsVisa(cfg), cfg.resume, cfg.profile, cfg.scanCriteria, cfg.minSalary, cfg.expTolerance, cfg.availability].join("|");
  let h = 0;
  for (let i = 0; i < x.length; i++) h = (h * 31 + x.charCodeAt(i)) | 0;
  return h;
}
async function cacheGetAll() {
  return (await chrome.storage.local.get("analyzed")).analyzed || {};
}
async function cachePut(urlForKey, job, r) {
  const all = await cacheGetAll();
  all[jobKey(urlForKey)] = { sig: cfgSig(), ts: Date.now(), r, job: { url: job.url, title: job.title, company: job.company, pageTitle: job.pageTitle } };
  const keys = Object.keys(all);
  if (keys.length > 400) keys.sort((a, b) => all[a].ts - all[b].ts).slice(0, keys.length - 400).forEach((k) => delete all[k]);
  await chrome.storage.local.set({ analyzed: all });
}
const ago = (ts) => {
  const m = Math.max(1, Math.round((Date.now() - ts) / 60000));
  return m < 60 ? t("ago.min", { n: m }) : m < 1440 ? t("ago.hr", { n: Math.round(m / 60) }) : t("ago.day", { n: Math.round(m / 1440) });
};


// 临时性错误（限流 / 过载）等一会儿再试，最多重试 2 次
async function withRetry(fn) {
  let wait = 8000;
  for (let i = 0; ; i++) {
    try {
      return await fn();
    } catch (e) {
      if (i < 2 && /429|quota|rate|overload|unavailable|503|timeout/i.test(String(e.message || e))) {
        await new Promise((r) => setTimeout(r, wait));
        wait *= 2;
        continue;
      }
      throw e;
    }
  }
}

// ---------- 批量分析的执行体：后台 service worker 和（后台没响应时的）弹窗共用 ----------
const slimJob = (j) => ({ url: j.url, title: j.title, company: j.company, pageTitle: j.pageTitle, chars: j.chars ?? (j.text ? j.text.length : undefined), thin: j.thin });
async function bgLog(m) {
  try { await chrome.storage.local.set({ bgLog: { ts: Date.now(), m: String(m).slice(0, 300) } }); } catch {}
}
// ctl: { isCancelled(): boolean, badge(job): void }
async function runBatch(tabs, ctl) {
  cfg = await store.get();
  cfg.provider = cfg.provider || "gemini";
  UI_LANG = cfg.uiLang === "en" || cfg.uiLang === "zh" ? cfg.uiLang : detectLang();
  const cache = await cacheGetAll();
  const sig = cfgSig();
  const rows = tabs.map((tb) => ({ key: jobKey(tb.url), tabId: tb.id, title: tb.title || tb.url, url: tb.url, status: "pending" }));
  rows.forEach((rw) => {
    const c = cache[rw.key];
    if (c && c.sig === sig) Object.assign(rw, { status: "done", r: c.r, job: slimJob(c.job), cached: true }); // 分析过的直接用，不调用 AI
  });
  const finished = () => rows.filter((x) => x.status === "done" || x.status === "error").length;
  const job = { status: "running", total: rows.length, done: finished(), rows, startedAt: Date.now(), heartbeat: Date.now() };
  const push = async () => {
    job.done = finished();
    job.heartbeat = Date.now();
    ctl.badge?.(job);
    await chrome.storage.local.set({ batchJob: job });
  };
  await push();
  await bgLog(`started: ${rows.length} tabs, ${rows.filter((x) => x.status === "done").length} cached`);
  // MV3 的 service worker 空闲约 30 秒会被回收：分析期间定时碰一下 API 保持存活
  const keepAlive = setInterval(() => { try { chrome.runtime.getPlatformInfo(() => {}); } catch {} push(); }, 20000);
  try {
    for (const rw of rows) {
      if (ctl.isCancelled()) break;
      if (rw.status === "done") continue;
      rw.status = "running";
      await push();
      try {
        try { await chrome.tabs.get(rw.tabId); } catch { throw new Error(t("bt.gone")); }
        const j = await readTabJobPatient({ id: rw.tabId, url: rw.url }, { activate: !!ctl.activate });
        if (!j || j.text.length < 200) throw new Error(t("bt.nobody"));
        if (j.noBody) throw new Error(t("bt.nobodytext")); // 没读到岗位描述正文：不去问 AI（对着页面外壳打分没有意义）
        const r = await withRetry(() => runAnalysis(j));
        // 没读全的（内容太短）结果只显示、打上警告，不存进收藏 / 缓存：不能让残缺文本得出的结论被当成"分析过了"
        if (!j.thin) {
          await saveToHistory(r, j);
          await cachePut(rw.url, j, r);
        }
        Object.assign(rw, { status: "done", r, job: slimJob(j) });
      } catch (e) {
        Object.assign(rw, { status: "error", error: String(e.message || e) });
      }
      await push();
    }
    job.status = ctl.isCancelled() ? "cancelled" : "done";
  } catch (e) {
    job.status = "interrupted";
    job.error = String(e.stack || e.message || e).slice(0, 300);
    await bgLog("ERROR " + job.error);
  } finally {
    clearInterval(keepAlive);
    if (job.status === "running") job.status = "interrupted";
    job.finishedAt = Date.now();
    await push();
    await bgLog("finished: " + job.status);
  }
}
